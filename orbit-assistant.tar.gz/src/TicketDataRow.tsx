import { ArchiveRestore, LoaderCircle } from "lucide-react";
import { TicketTableRow } from "./TicketCard.js";
import { TicketMetadata } from "./TicketMetadata.js";
import { LocalDeveloper, StatusBadge, TicketStatus } from "./TicketControls.js";
import { AzureAssignee } from "./AzureAssignee.js";

export function TicketDataRow({
  ticket: t,
  columns,
  settings,
  context,
  checked,
  onToggle,
  onChange,
  onRemove,
  onRestore,
  restoring = false,
  highlighted = false,
}: any) {
  const local = t.imported !== false || t.inTrash;
  const tone = t.inTrash ? "trash" : t.imported === false ? "new" : undefined;
  const date = (v: string | number) =>
    v ? new Date(v).toLocaleString("ru-RU") : "—";
  return (
    <TicketTableRow
      id={t.id}
      columns={columns.count}
      columnOrder={columns.order}
      hideActions={columns.hidden("actions")}
      tone={tone}
      highlighted={highlighted}
      onRemove={onRemove}
      actions={
        <>
          {local && (
            <TicketMetadata
              ticket={t}
              context={context}
              field="notes"
              onChange={onChange}
            />
          )}
          {onRestore && (
            <button
              type="button"
              className="secondary"
              disabled={restoring}
              title="Восстановить тикет"
              aria-label={`Восстановить тикет #${t.id}`}
              onClick={onRestore}
            >
              {restoring ? (
                <LoaderCircle size={17} className="spin" />
              ) : (
                <ArchiveRestore size={17} />
              )}
            </button>
          )}
        </>
      }
    >
      <td className="ticket-selection-column">
        <input
          className="ticket-checkbox"
          type="checkbox"
          aria-label={`Выбрать тикет #${t.id}`}
          checked={checked}
          onChange={onToggle}
        />
      </td>
      <td>
        <div className="ticket-id-type">
          <a
            className="ticket-link"
            href={t.url}
            target="_blank"
            rel="noreferrer"
          >
            #{t.id}
          </a>
          <StatusBadge
            state={t.type || "Тип не указан"}
            kind="type"
            colors={settings?.typeColors}
          />
        </div>
      </td>
      <td>
        <b className="ticket-title-clamp" title={t.title}>
          {t.title}
        </b>
      </td>
      <td data-column="state" hidden={columns.hidden("state")}>
        <TicketStatus
          id={t.id}
          source={t.source}
          state={t.state}
          colors={settings?.statusColors}
          onChange={onChange}
        />
      </td>
      <td data-column="priority" hidden={columns.hidden("priority")}>
        {local ? (
          <TicketMetadata
            ticket={t}
            context={context}
            field="priority"
            onChange={onChange}
          />
        ) : (
          "N/A"
        )}
      </td>
      <td data-column="tags" hidden={columns.hidden("tags")}>
        {local ? (
          <TicketMetadata
            ticket={t}
            context={context}
            field="tags"
            onChange={onChange}
          />
        ) : (
          "N/A"
        )}
      </td>
      <td data-column="azureTags" hidden={columns.hidden("azureTags")}>
        <span
          className="ticket-tag-list azure-ticket-tags"
          title="Azure теги · только чтение"
        >
          {t.azureTags?.length
            ? t.azureTags.map((tag: string) => (
                <span className="badge" key={tag}>
                  {tag}
                </span>
              ))
            : "—"}
        </span>
      </td>
      <td data-column="assigned" hidden={columns.hidden("assigned")}>
        <AzureAssignee ticket={t} onChange={onChange} />
      </td>
      <td
        data-column="developer_name"
        hidden={columns.hidden("developer_name")}
      >
        {local ? (
          <LocalDeveloper ticket={t} context={context} onChange={onChange} />
        ) : (
          "N/A"
        )}
      </td>
      <td data-column="added_at" hidden={columns.hidden("added_at")}>
        {local ? date(t.added_at) : "N/A"}
      </td>
      {columns.order.includes("removedAt") ? (
        <>
          <td data-column="removedAt" hidden={columns.hidden("removedAt")}>
            {date(t.removedAt)}
          </td>
          <td data-column="expiresAt" hidden={columns.hidden("expiresAt")}>
            {date(t.expiresAt)}
          </td>
        </>
      ) : null}
      {columns.order.includes("synced_at") && (
        <td data-column="synced_at" hidden={columns.hidden("synced_at")}>
          {local ? date(t.synced_at) : "N/A"}
        </td>
      )}
    </TicketTableRow>
  );
}
